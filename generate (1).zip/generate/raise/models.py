from django.db import models

# Create your models here.
from xml.dom.minidom import Document
from django.db import models
from django.conf import settings

# Create your models here.

class Feedback(models.Model):
    
    name = models.CharField(max_length=100,null=True)
    
    #date_of_birth = models.DateField(auto_now_add=False,null=True)
    #father_name  = models.CharField(max_length=100,null=False ,default = 0)
    #mother_name  = models.CharField(max_length=100,null=False ,default = 0)
    email = models.CharField(max_length=50,null=True)
    phone_number = models.IntegerField()
    wp_number = models.IntegerField()
    #applied_domain = models.CharField(max_length=100,null=True)
    #specilization = models.CharField(max_length=500,null=True)
    issue = models.CharField(max_length=500,null=True)
    image = models.FileField(upload_to='issue-image/' ,default=None,null=True)
    
    
    
    

    def __str__(self):
        
        return self.name
