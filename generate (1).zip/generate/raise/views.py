from django.shortcuts import render

# Create your views here.
from .models import Feedback
from rest_framework import viewsets
from rest_framework import permissions
from .serializers import FeedbackSerializer


class FeedbackViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows admission to be viewed or edited.
    """
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer
    permission_classes = [permissions.AllowAny]